import React from 'react'

export function CustomerPage() {
  return (
    <div>CustomerPage</div>
  )
}
